require 'test_helper'

class UsersControllerTest < ActionController::TestCase
  def setup
    @user = users(:one) # Assuming you have fixture data for users
  end

  test 'should get index' do
    sign_in @user # Assuming you have a sign_in method to authenticate the user
    get :index
    assert_response :success
    # Add assertions to check the expected behavior
  end

  test 'should get settings' do
    sign_in @user # Assuming you have a sign_in method to authenticate the user
    get :settings
    assert_response :success
    # Add assertions to check the expected behavior
  end

  test 'should get my_account' do
    sign_in @user # Assuming you have a sign_in method to authenticate the user
    get :my_account
    assert_response :success
    # Add assertions to check the expected behavior
  end

  test 'should destroy user session' do
    sign_in @user # Assuming you have a sign_in method to authenticate the user
    delete :destroy
    assert_redirected_to root_path
    # Add assertions to check the expected behavior
  end

  test 'should get password_change' do
    sign_in @user # Assuming you have a sign_in method to authenticate the user
    get :password_change
    assert_response :success
    # Add assertions to check the expected behavior
  end

  test 'should update password' do
    sign_in @user # Assuming you have a sign_in method to authenticate the user
    patch :password_update, params: {
      user: { password: 'newpassword', password_confirmation: 'newpassword' }
    }
    assert_redirected_to settings_path_url
    # Add assertions to check the expected behavior
  end

  # Add more tests for the remaining actions

end
