require 'test_helper'

class CheckoutControllerTest < ActionController::TestCase
  def setup
    @cart = carts(:one) # Assuming you have fixture data for carts
    @user = users(:one) # Assuming you have fixture data for users
  end

  test 'should get index' do
    get :index, session: { cart_id: @cart.id }
    assert_response :success
    # Add assertions to check the expected behavior
  end

  test 'should get history' do
    sign_in @user # Assuming you have a sign_in method to authenticate the user
    get :history
    assert_response :success
    # Add assertions to check the expected behavior
  end

  test 'should get success' do
    get :success, session: { cart_id: @cart.id }
    assert_response :success
    # Add assertions to check the expected behavior
  end

  test 'should create user address and payment' do
    sign_in @user # Assuming you have a sign_in method to authenticate the user
    post :create, params: {
      user_address: { address: '123 Street', city: 'City', zip_code: '12345', phone_number: '1234567890' },
      user_payment: { payment_type: 'Type', provider: 'Provider', account_number: '1234567890', expiry: '12/23' }
    }
    assert_redirected_to success_path
    # Add assertions to check the expected behavior
  end
end
