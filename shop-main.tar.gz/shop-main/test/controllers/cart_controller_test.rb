require 'test_helper'

class CartControllerTest < ActionController::TestCase
  def setup
    @cart = carts(:one) # Assuming you have fixture data for carts
    @product = products(:one) # Assuming you have fixture data for products
  end

  test 'should add product to cart' do
    post :add_product_to_cart, params: { product_id: @product.id }, session: { cart_id: @cart.id }
    assert_response :success
    # Add assertions to check the expected behavior
  end

  test 'should delete product from cart' do
    delete :delete_product_from_cart, params: { product_id: @product.id }, session: { cart_id: @cart.id }
    assert_redirected_to action: 'show'
    # Add assertions to check the expected behavior
  end

  test 'should increase product quantity' do
    # Set up the initial quantity for the product in the cart
    @cart.carts_products.create(product: @product, quantity: 1)

    post :increase_product_quantity, params: { product_id: @product.id }, session: { cart_id: @cart.id }
    assert_redirected_to action: 'show'
    # Add assertions to check the expected behavior
  end

  test 'should decrease product quantity' do
    # Set up the initial quantity for the product in the cart
    @cart.carts_products.create(product: @product, quantity: 2)

    post :decrease_product_quantity, params: { product_id: @product.id }, session: { cart_id: @cart.id }
    assert_redirected_to action: 'show'
    # Add assertions to check the expected behavior
  end

  test 'should show cart' do
    get :show, session: { cart_id: @cart.id }
    assert_response :success
    # Add assertions to check the expected behavior
  end
end
