require "test_helper"

class AttributesProductTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
