require "test_helper"

class UserAdressTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
