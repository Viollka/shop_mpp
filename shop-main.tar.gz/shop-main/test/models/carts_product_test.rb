require "test_helper"

class CartsProductTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
