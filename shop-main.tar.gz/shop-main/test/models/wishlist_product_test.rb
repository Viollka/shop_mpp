require "test_helper"

class WishlistProductTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
