require "test_helper"

class UserPaymentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
