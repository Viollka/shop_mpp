# frozen_string_literal: true

# This is the ProductsHelper module
module ProductsHelper
end
