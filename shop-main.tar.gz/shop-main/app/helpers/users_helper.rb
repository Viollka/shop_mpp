# frozen_string_literal: true

# This is the UsersHelper module
module UsersHelper
end
