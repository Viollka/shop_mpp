# frozen_string_literal: true

# This is the Discount class
class Discount < ApplicationRecord
  belongs_to :product
end
